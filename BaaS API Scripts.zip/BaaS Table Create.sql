Here is the schema for creating the base tables
-- ------------------------------------------------------------------------------------
--  Teradata Schema for BaaS Metadata Tables
-- ------------------------------------------------------------------------------------
 
 
drop table baradmin.RetainedCopies;
 
CREATE MULTISET TABLE baradmin.RetainedCopies
      ,Fallback
(
      executionId VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      backupSetId VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      name VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      jobId VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      jobName VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      backupMechanism VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      status VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      sourceSite VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      targetSite VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      protected BYTEINT,
      creationTime VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      size VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      runType VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      siteType VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      load_date VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      current_record VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC
)
Primary Index ( executionId )
;
 
Collect Statistics
  Column ( jobId )
, Column ( executionId )
On baradmin.RetainedCopies
;
 
 
 
drop table baradmin.DataProtectionPlans;
 
CREATE MULTISET TABLE baradmin.DataProtectionPlans
      ,Fallback
(
      jobId VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      siteId VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      name VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      sourceSite VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      targetSite VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      description VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      active BYTEINT,
      priority BIGINT,
      jobType VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      retainedCopiesCount BIGINT,
      autoAbort BYTEINT,
      autoAbortInMinutes BIGINT,
      nextRunTime VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      backupMechanism VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      "objects" VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      schedules VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      "history" VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      nextRuns VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      retainedCopies VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      backupType VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      restoreJobSettings VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      "targetSiteDetails.targetSiteId" VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      "targetSiteDetails.targetRetentionCopiesCount" FLOAT,
      "targetSiteDetails.retentionSourceSite" VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      "lastExecutionDetails.status" VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      "lastExecutionDetails.backupSetSize" FLOAT,
      "lastExecutionDetails.startTime" VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      "lastExecutionDetails.endTime" VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      "lastExecutionDetails.backupJobId" VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      "lastExecutionDetails.backupJobExecutionId" VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      "lastExecutionDetails.restoreExecutionId" VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      targetSiteDetails FLOAT,
      load_date VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC,
      current_record VARCHAR(1024) CHARACTER SET UNICODE NOT CASESPECIFIC
)
Primary Index (jobId )
;
 
Collect Statistics
  Column (jobId )
On baradmin.DataProtectionPlans
;
 