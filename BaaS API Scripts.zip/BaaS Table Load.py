# Copyright 2024 Teradata Corporation
# Copyright Mark Rolfo
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with this program; if not, see http://www.gnu.org/licenses/.
 
import warnings
from datetime import datetime
import pandas as pd
import requests
from requests.auth import HTTPBasicAuth
import sqlalchemy
 
from myconfig import *
 
print('--------------------------------------------------------------------')
print(' Teradata Services BaaS Metadata Load Process')
print('--------------------------------------------------------------------\n')
# --------------------------------------------------------------------
#  ignore pandas conversion
# --------------------------------------------------------------------
warnings.filterwarnings('ignore')
basic = HTTPBasicAuth(username, password)
headers = {'Content-Type': 'application/json'}
 
# --------------------------------------------------------------------
#  Connect to Teradata database
# --------------------------------------------------------------------
db_connect_url = sqlalchemy.engine.url.URL(
    drivername='teradatasql',
    username=td_username,
    password=td_password,
    host=td_host,
    database=td_username)
dbconnect = sqlalchemy.create_engine(db_connect_url)
 
# --------------------------------------------------------------------
#  Defined post queries to get the different data sets
# --------------------------------------------------------------------
getretainedcopies = "{\"query\":\"query getRetainedCopies ($page: Int, $pageSize: Int) {\\n    getRetainedCopies (page: $page, pageSize: $pageSize) {\\n        executionId\\n        backupSetId\\n        name\\n        jobId\\n        jobName\\n        backupMechanism\\n        status\\n        sourceSite\\n        targetSite\\n        protected\\n        creationTime\\n        size\\n        runType\\n        siteType\\n    }\\n}\",\"variables\":{\"page\":0,\"pageSize\":1000}}"
getdataprotectionplans = "{\"query\":\"query getCustomerDataProtectionPlans ($page: Int, $pageSize: Int) {\\n    getCustomerDataProtectionPlans (page: $page, pageSize: $pageSize) {\\n        jobId\\n        siteId\\n        name\\n        sourceSite\\n        targetSite\\n        active\\n        jobType\\n        retainedCopiesCount\\n        backupMechanism\\n        backupType\\n    }\\n}\",\"variables\":{\"page\":0,\"pageSize\":1000}}"
getexecutionhistory = "{\"query\":\"query getCustomerExecutionHistory ($siteId: String, $page: Int, $pageSize: Int) {\\n    getCustomerExecutionHistory (siteId: $siteId, page: $page, pageSize: $pageSize) {\\n        executionId\\n        name\\n        jobType\\n        siteId\\n        jobId\\n        targetSite\\n        startTime\\n        endTime\\n        status\\n        savesetId\\n        savesetSize\\n        executionDeleted\\n        retainedCopy\\n        runType\\n    }\\n}\",\"variables\":{\"page\":0,\"pageSize\":1000}}"
 
# --------------------------------------------------------------------
#  Retained copies 
# --------------------------------------------------------------------
print("Loading RetainedCopies")
retainedcopies = requests.request("POST", url, headers=headers, auth=basic, data=getretainedcopies)
rc1 = pd.json_normalize(retainedcopies.json()['data']['getRetainedCopies'])
rc1['load_date'] = datetime.today()
rc1['current_record'] = 'Y'
rc1 = rc1.fillna(0)
rcdf = rc1.astype(
    dict(executionId='int', backupSetId='int64', name='string', jobId='int64', jobName='string',
         backupMechanism='string',
         status='string', sourceSite='string', targetSite='string', protected='string', creationTime='datetime64[s]',
         size='int', runType='string', siteType='string', load_date='datetime64[s]', current_record='string'))
 
loadrc1 = rcdf.to_sql(name='stage_RetainedCopies', con=dbconnect, index=False, schema=td_username, if_exists='replace')
 
# print(rt1)
 
dbconnect.execute("Update baradmin.RetainedCopies SET current_record = 'N'")
dbconnect.execute("Insert Into baradmin.RetainedCopies select * from baradmin.stage_RetainedCopies")
dbconnect.execute("Collect Statistics On baradmin.RetainedCopies")
# --------------------------------------------------------------------
#  Backup Jobs - called Protection Plans
# --------------------------------------------------------------------
print("Loading DataProtectionPlans")
dataprotectionplans = requests.request("POST", url, headers=headers, auth=basic, data=getdataprotectionplans)
rc2 = pd.json_normalize(dataprotectionplans.json()['data']['getCustomerDataProtectionPlans'])
rc2['load_date'] = datetime.today()
rc2['current_record'] = 'Y'
rc2 = rc2.fillna(0)
 
rc2df = rc2.astype(
    dict(jobId='int', siteId='string', name='string', sourceSite='string', targetSite='string', active='string',
         jobType='string', retainedCopiesCount='int', backupMechanism='string', backupType='string',
         load_date='datetime64[s]', current_record='string'))
 
loadrc2 = rc2df.to_sql(name='stage_DataProtectionPlans', con=dbconnect, index=False, schema=td_username,
                       if_exists='replace')
dbconnect.execute("Update baradmin.DataProtectionPlans SET current_record = 'N'")
dbconnect.execute("Insert Into baradmin.DataProtectionPlans select * from baradmin.stage_DataProtectionPlans")
dbconnect.execute("Collect Statistics On baradmin.DataProtectionPlans")
 
# --------------------------------------------------------------------
#  Execution History
# --------------------------------------------------------------------
print("Loading DataExecutionHistory")
executionhistory = requests.request("POST", url, headers=headers, auth=basic, data=getexecutionhistory)
rc3 = pd.json_normalize(executionhistory.json()['data']['getCustomerExecutionHistory'])
rc3['load_date'] = datetime.today()
rc3['current_record'] = 'Y'
rc3 = rc3.fillna(0)
 
rc3df = rc3.astype(
                    dict(executionId='int',
                         name='string',
                         jobType='string',
                         siteId='string',
                         jobId='int',
                         targetSite='string',
                         startTime='datetime64[s]',
                         endTime='datetime64[s]',
                         status='string',
                         savesetId='int',
                         savesetSize='int',
                         executionDeleted='int',
                         retainedCopy='int',
                         runType='string',
                         load_date='datetime64[s]',
                         current_record='string'))
 
 
loadrc3 = rc3df.to_sql(name='stage_DataExecutionHistory', con=dbconnect, index=False, schema=td_username, if_exists='replace')
 
dbconnect.execute("Update baradmin.DataExecutionHistory SET current_record = 'N'")
 
dbconnect.execute("Insert Into baradmin.DataExecutionHistory select * from baradmin.stage_DataExecutionHistory")
dbconnect.execute("Collect Statistics On baradmin.DataExecutionHistory")
 
# --------------------------------------------------------------------
#  end of run success message
# --------------------------------------------------------------------
 
print("\nData Successfully Loaded to Teradata!")