# myconfig.py:
url = https://api.cloud.vantage.teradata.com/graphql/
username = 'CONSOLE USERNAME
password = 'CONSOLE PASSWORD'
td_host ="TDP_ID
td_username ="TDUSERNAME"
td_password ="TDPASSWORD"
 